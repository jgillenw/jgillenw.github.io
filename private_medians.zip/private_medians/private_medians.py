# coding=utf-8
# Copyright 2020 The Private Medians Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Implementation of smooth sensitivity and exponential mechanism for medians."""

import numpy as np


def update_smooth_sensitivity(lower_index, upper_index, lower_bound,
                              upper_bound, x_sorted, beta,
                              prev_smooth_sensitivity, min_value, max_value):
  """Recursively helps compute smooth sensitivity for the median task.

  Updates prev_smooth_sensitivity by exploring the local sensitivity of all
  possible indices i,j satisfying lower_index <= i <= upper_index.
  lower_bound <= j <= upper_bound. Special indices -1 and n = x_sorted.size
  are allowed, where x_sorted[-1] = min_value and x_sorted[n]= max_value.

  Note: Expects data to be sorted.

  Algorithm can be found in the work "Smooth Sensitivity and Sampling in Private
  Data Analysis (STOC 2007)" by Nissim et al.

  Args:
    lower_index: The lower index to search smooth sensitivity index i.
    upper_index: The upper index to search smooth sensitivity index i.
    lower_bound: The lower bound on the smooth sensitivity  index j.
    upper_bound: The upper bound on the smooth sensitivity index j.
    x_sorted: Sorted dataset.
    beta: The beta parameter for smooth sensitivity.
    prev_smooth_sensitivity: Previous smooth sensitivity.
    min_value: Min value allowed in the dataset; x_sorted[0] >= min_value.
    max_value: Max value allowed in the dataset; x_sorted[n] <= max_value.

  Returns:
    An updated value for the smooth sensitivity of x_sorted for the median task.
  """
  smooth_sensitivity = prev_smooth_sensitivity
  n = x_sorted.size

  # Choose an index i to explore, or return if not possible.
  if lower_index > upper_index:
    return smooth_sensitivity
  i = int((lower_index + upper_index) / 2)

  # Scan the eligible indices j.
  base_value = min_value
  if i > -1:
    base_value = x_sorted[i]
  js = np.arange(lower_bound, upper_bound + 1)
  j_vals = np.empty(upper_bound + 1 - lower_bound)

  js_lt_n_bool = js < n
  js_lt_n = js[js_lt_n_bool]
  j_vals[js_lt_n_bool] = x_sorted[js_lt_n]
  j_vals[np.logical_not(js_lt_n_bool)] = max_value

  dataset_distances = js - (i + 1)
  local_sensitivities = j_vals - base_value

  weighted_sensitivities = np.exp(
      -beta * dataset_distances) * local_sensitivities

  max_sensitivity_index = np.argmax(weighted_sensitivities)
  current_max_sensitivity = weighted_sensitivities[max_sensitivity_index]
  max_sensitivity_index = js[max_sensitivity_index]

  smooth_sensitivity = np.maximum(smooth_sensitivity, current_max_sensitivity)

  smooth_sensitivity = np.maximum(
      smooth_sensitivity,
      update_smooth_sensitivity(i + 1, upper_index, max_sensitivity_index,
                                upper_bound, x_sorted, beta, smooth_sensitivity,
                                min_value, max_value))
  smooth_sensitivity = np.maximum(
      smooth_sensitivity,
      update_smooth_sensitivity(lower_index, i - 1, lower_bound,
                                max_sensitivity_index, x_sorted, beta,
                                smooth_sensitivity, min_value, max_value))
  return smooth_sensitivity


def compute_smooth_sensitivity(x_sorted, min_value, max_value, beta):
  """Computes the smooth sensitivity for the median task.

  Args:
    x_sorted: Sorted dataset.
    min_value: Min value allowed in x_sorted. x_sorted[0] must be greater than
      or equal to min_value.
    max_value: Max value allowed in x_sorted. x_sorted[x_sorted.size] must be
      less than or equal to max_value.
    beta: The beta parameter for smooth sensitivity.

  Returns:
    The smooth sensitivity of x_sorted for the median task.
  """
  n = x_sorted.size
  if n == 1:
    return max_value - min_value
  median_index = int((n - 1) / 2)
  return update_smooth_sensitivity(-1, median_index, median_index, n, x_sorted,
                                   beta, 0.0, min_value, max_value)


def compute_smooth_sensitivity_approx(x_sorted, min_value, max_value, beta):
  """Computes a 2-approximation to the smooth sensitivity for the median task.

  Faster than computing the true smooth sensitivity, but can be up to a factor
  of two larger.

  Args:
    x_sorted: Sorted dataset.
    min_value: Min value allowed in x_sorted. x_sorted[0] must be greater than
      or equal to min_value.
    max_value: Max value allowed in x_sorted. x_sorted[x_sorted.size] must be
      less than or equal to max_value.
    beta: The beta parameter for smooth sensitivity.

  Returns:
    An approximation to the smooth sensitivity of x_sorted for the median task.
  """
  n = x_sorted.size
  median_index = int((n - 1) / 2)

  smooth_sensitivity_approx = 0
  for k in range(n + 1):
    larger_index = median_index + k + 1
    smaller_index = median_index - k - 1

    larger_value = max_value if larger_index > n - 1 else x_sorted[larger_index]
    smaller_value = min_value if smaller_index < 0 else x_sorted[smaller_index]

    smooth_sensitivity_approx = max(
        smooth_sensitivity_approx,
        np.exp(-k * beta) * (larger_value - smaller_value))

  return smooth_sensitivity_approx


def smooth_sensitivity_median(x_sorted, epsilon, min_value, max_value, delta,
                              num_estimates):
  """Returns private medians via the smooth sensitivity mechanism.

  Args:
    x_sorted: Sorted dataset.
    epsilon: Epsilon of differential privacy.
    min_value: Min value allowed in x_sorted. x_sorted[0] must be greater than
      or equal to min_value.
    max_value: Max value allowed in x_sorted. x_sorted[x_sorted.size] must be
      less than or equal to max_value.
    delta: Delta of differential privacy. If delta=0, noise will be
      Cauchy-distributed; otherwise, noise will be Laplace-distributed.
    num_estimates: Number of times to run the algorithm.

  Returns:
    A list with num_estimates versions of the private median.
  """
  assert x_sorted[0] >= min_value
  assert x_sorted[-1] <= max_value

  n = x_sorted.size
  median_index = int((n - 1) / 2)
  median = x_sorted[median_index]

  if delta == 0:
    # For the Cauchy distribution used below, gamma = 2.  (Would need a sample
    # from a generalization of Cauchy to change gamma to a different value.)
    gamma = 2.0
    alpha = epsilon / (2.0 * (gamma + 1.0))
    beta = alpha
    ss = compute_smooth_sensitivity(x_sorted, min_value, max_value, beta)
    rv = np.random.standard_cauchy(size=num_estimates)
  else:
    # This is the beta from the smooth sensitivity work:
    #   beta = epsilon / (2.0 * np.log(2.0 / delta))
    # But due to the incorrectness of the proof of Lemma 2.6, it should
    # actually be:
    real_divisor = 2.0 * delta / (np.exp(epsilon / 2.0) + 1.0)
    beta = epsilon / (2.0 * np.log(2.0 / real_divisor))
    ss = compute_smooth_sensitivity(x_sorted, min_value, max_value, beta)
    alpha = epsilon / 2.0
    rv = np.random.laplace(0, 1.0, size=num_estimates)

  return np.maximum(min_value, np.minimum(max_value, median + rv * ss / alpha))


def naive_exponential_method_median(x_sorted, epsilon, min_value, max_value,
                                    num_estimates):
  """Returns private medians via a naive exponential mechanism.

  Note: Sampling is done in a manner that may have numerical issues for larger
  datasets.

  Args:
    x_sorted: Sorted dataset.
    epsilon: Epsilon of differential privacy.
    min_value: Min value allowed in x_sorted. x_sorted[0] must be greater than
      or equal to min_value.
    max_value: Max value allowed in x_sorted. x_sorted[x_sorted.size] must be
      less than or equal to max_value.
    num_estimates: Number of times to run the algorithm.

  Returns:
    A list with num_estimates versions of the private median.
  """
  assert x_sorted[0] >= min_value
  assert x_sorted[-1] <= max_value

  n = x_sorted.size
  start = 2 if n % 2 == 1 else 1
  utilities = np.concatenate(((np.arange(-n, 0,
                                         2), -np.arange(start, n + 2, 2))))

  x_sorted = np.concatenate([[min_value], x_sorted, [max_value]])
  interval_widths = x_sorted[1:] - x_sorted[0:(n + 1)]
  nonzeros = interval_widths != 0.0
  interval_widths = interval_widths[nonzeros]
  utilities = utilities[nonzeros]

  sensitivity = 1
  scaling = epsilon / (2.0 * sensitivity)
  pvals = np.exp(scaling * utilities) * interval_widths
  pvals = pvals / np.sum(pvals)

  ix_lefts = np.random.choice(range(pvals.size), size=num_estimates, p=pvals)
  estimates = np.zeros(num_estimates)
  for i in range(num_estimates):
    ix_left = ix_lefts[i]
    estimates[i] = np.random.uniform(x_sorted[ix_left], x_sorted[ix_left + 1],
                                     1)[0]
  return estimates


def exponential_method_median(x_sorted, epsilon, min_value, max_value,
                              num_estimates):
  """Returns private medians via a numerically-stable exponential mechanism.

  Args:
    x_sorted: Sorted dataset.
    epsilon: Epsilon of differential privacy.
    min_value: Min value allowed in x_sorted. x_sorted[0] must be greater than
      or equal to min_value.
    max_value: Max value allowed in x_sorted. x_sorted[x_sorted.size] must be
      less than or equal to max_value.
    num_estimates: Number of times to run the algorithm.

  Returns:
    A list with num_estimates versions of the private median.
  """
  assert x_sorted[0] >= min_value
  assert x_sorted[-1] <= max_value

  n = x_sorted.size
  start = 2 if n % 2 == 1 else 1
  utilities = np.concatenate(((np.arange(-n, 0,
                                         2), -np.arange(start, n + 2, 2))))

  x_sorted = np.concatenate([[min_value], x_sorted, [max_value]])
  interval_widths = x_sorted[1:] - x_sorted[0:(n + 1)]
  nonzeros = interval_widths != 0.0
  interval_widths = interval_widths[nonzeros]
  utilities = utilities[nonzeros]

  u = np.random.uniform(0.0, 1.0, utilities.size * num_estimates).reshape(
      utilities.size, num_estimates)
  utilities = utilities.reshape((utilities.size, 1))
  interval_widths = interval_widths.reshape(utilities.size, 1)

  z = np.log(np.log(
      1.0 / u)) - np.log(interval_widths) - epsilon * utilities / 2.0
  ix_lefts = np.argmin(z, axis=0)
  estimates = np.zeros(num_estimates)
  for i in range(num_estimates):
    ix_left = ix_lefts[i]
    estimates[i] = np.random.uniform(x_sorted[ix_left], x_sorted[ix_left + 1],
                                     1)[0]
  return estimates
