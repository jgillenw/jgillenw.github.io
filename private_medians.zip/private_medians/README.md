This project implements the smooth sensitivity mechanism and exponential
mechanism for medians. Smooth sensitivity calculation is based on [1]. The
exponential mechanism has a na\"ive implementation and a more numerically stable
one. The library also provides a faster 2-approximation calculation of smooth
sensitivity.

The file experiments.py contains code to recreate experimental results for an
ICML submission.

[1] Kobbi Nissim, Sofya Raskhodnikova, and Adam Smith.  Smooth Sensitivity and
Sampling in Private Data Analysis.  STOC 2007.  URL:
http://www.cse.psu.edu/~ads22/pubs/NRS07/NRS07-full-draft-v1.pdf